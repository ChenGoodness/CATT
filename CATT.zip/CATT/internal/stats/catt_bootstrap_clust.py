import numpy as np
from scipy.stats import norm
from scipy.special import erf
from scipy.optimize import minimize

from circstat_matlab_master import circ_raotest, circ_rtest, circ_otest
from internal.utilities.catt_shuffle import catt_shuffle
from internal.utilities.catt_wrap2heart import catt_wrap2heart


def wrap_to_2pi(angles):
    return angles % (2 * np.pi)

def catt_bootstrap_clust(catt, *args):
    # Set default options
    stats = {
        "opt": {
            "nloops": 10000,
            "test": "otest"
        }
    }

    # Extract relevant info
    # IBIs = np.array([rr["IBI"] for rr in catt["RR"] if not np.isnan(rr["onset"])])
    # Create an empty list to store non-nan IBI values
    IBIs_list = []
    onsets_list = []
    # Walk through each element of catt["RR"]
    for rr in catt["RR"]:
        # Check if "onset" in rr is not NaN
        if not np.isnan(rr["IBI"]):
            # If it is not a NaN, add its corresponding IBI to the list
            IBIs_list.append(rr["IBI"])
        if not np.isnan(rr["onset"]):
            # If it is not a NaN, add its corresponding IBI to the list
            onsets_list.append(rr["onset"])

    # Convert list to NumPy array
    IBIs = np.array(IBIs_list)
    onsets = np.array(onsets_list)
    # onsets = np.array([rr["onset"] for rr in catt["RR"] if not np.isnan(rr["onset"])])

    # Check inputs have sufficient data
    assert len(IBIs) > 2, "Need at least 5 IBIs"
    assert len(onsets) > 2, "Need at least 5 onsets"

    # Interpret optional inputs
    for arg in args:
        if isinstance(arg, str):
            if arg.lower() == 'otest':
                stats['opt']['test'] = 'otest'
            elif arg.lower() == 'rao':
                stats['opt']['test'] = 'rao'
            elif arg.lower() == 'rayleigh':
                stats['opt']['test'] = 'rayleigh'
            elif arg.lower() not in ['rao', 'rayleigh', 'otest']:
                print(f"Warning in <strong>catt_bootstrap_clust</strong>: input {arg} is unknown. Ignoring...")
        elif isinstance(arg, (int, float)):
            stats['opt']['nloops'] = arg
            assert stats['opt']['nloops'] >= 100, "Error in <strong>catt_bootstrap_clust</strong>: use at least 100 permutations"

    # Set appropriate test function based on selected test
    if stats["opt"]["test"] == "rao":
        stats["opt"]["r_fcn"] = circ_raotest
    elif stats["opt"]["test"] == "rayleigh":
        stats["opt"]["r_fcn"] = circ_rtest
    else:  # "otest" as default
        stats["opt"]["r_fcn"] = circ_otest

    # Wrap to heart and calculate true test stat
    catt["wrapped"] = catt_wrap2heart(onsets, IBIs, catt.get("qt"))
    if stats["opt"]["test"] == "rao":
        _, stats["test_stat"] = circ_raotest.circ_raotest(catt["wrapped"]["onsets_rad"])
    elif stats["opt"]["test"] == "rayleigh":
        _, stats["test_stat"] = circ_rtest.circ_rtest(catt["wrapped"]["onsets_rad"])
        # stats["opt"]["r_fcn"] = circ_rtest
    else:  # "otest" as default
        _, stats["test_stat"] = circ_otest.circ_otest(catt["wrapped"]["onsets_rad"])
        # stats["opt"]["r_fcn"] = circ_otest
    # _, stats["test_stat"] = stats["opt"]["r_fcn"](catt["wrapped"]["onsets_rad"])

    # Perform permutation testing
    stats["null"] = np.zeros(stats["opt"]["nloops"])
    for i in range(stats["opt"]["nloops"]):
        sIBI, sOnset = catt_shuffle(IBIs, onsets)
        V = catt_wrap2heart(sOnset, sIBI, catt.get("qt"))
        V_rad = wrap_to_2pi(V["onsets_rad"])

        if stats["opt"]["test"] == "rao":
            _, stats["null"][i] = circ_raotest.circ_raotest(V_rad)
        elif stats["opt"]["test"] == "rayleigh":
            _, stats["null"][i] = circ_rtest.circ_rtest(V_rad)
            # stats["opt"]["r_fcn"] = circ_rtest
        else:  # "otest" as default
            _, stats["null"][i] = circ_otest.circ_otest(V_rad)

    # Calculate p-value
    pval = np.sum(stats["null"] >= stats["test_stat"]) / stats["opt"]["nloops"]

    # Calculate z-score for group-level comparisons
    if stats["opt"]["test"] == "otest":
        if np.std(stats["null"]) == 0:
            stats["zscore"] = 0
        else:
            stats["zscore"] = -(stats["test_stat"] - np.mean(stats["null"])) / np.std(stats["null"])
    else:
        stats["zscore"] = (stats["test_stat"] - np.mean(stats["null"])) / np.std(stats["null"])

    # Populate catt with results
    catt["stats"] = stats
    catt["stats"]["pval"] = pval

    return pval, stats, catt
