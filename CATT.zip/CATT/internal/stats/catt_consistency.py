import numpy as np
from scipy.stats import norm

from dependencies.fdr_correct import fdr_correct
from internal.stats.catt_bootstrap_diff import catt_bootstrap_diff
from internal.utilities.catt_wrap2heart import catt_wrap2heart
from internal.utilities.catt_bin_circ_data import catt_bin_circ_data

def circ_rad2ang(alpha):
    """Convert radians to degrees."""
    return np.degrees(alpha)

def catt_consistency(catt_group, nbins=8, verbose=True):
    """
    Test for consistency across the circular distribution of cardiac-wrapped onsets across participants.

    Parameters:
    - catt_group: list of participant catt structures.
    - nbins: int, optional, default is 8. Number of bins to use.
    - verbose: bool, optional, default is True. If True, prints results to the console.

    Returns:
    - output: dict containing results.
    """
    # Initialize results
    output = {}

    # Get global options (assuming catt_opts.wrap2 is globally accessible)
    wrap2 = "rpeak"  # Example, replace with catt_opts.catt_opts["wrap2"]

    if wrap2 == "rpeak":
        # Define bins
        bins = np.linspace(0, 2 * np.pi, nbins + 1)

        # Loop participants and compute proportions
        props = []
        for participant in catt_group:
            # Get thetas and wrap
            wrapped = catt_wrap2heart(participant)
            thetas = wrapped["onsets_rad"]

            # Bin data
            binned = catt_bin_circ_data(thetas, nbins)
            participant_props = [np.sum(binned == j) / len(binned) for j in range(1, nbins + 1)]
            props.append(participant_props)

    elif wrap2 == "twav":
        assert nbins % 2 == 0, "Number of bins must be even when wrapping to t-wave."

        # Define bins
        bins = np.linspace(-np.pi, np.pi, nbins + 1)

        # Loop participants and compute proportions
        props = []
        for participant in catt_group:
            # Get thetas and wrap
            wrapped = catt_wrap2heart(participant)
            thetas = wrapped["onsets_rad"]

            # Bin data
            binned = catt_bin_circ_data(thetas, nbins)
            participant_props = []
            for j in range(1, nbins // 2 + 1):
                participant_props.append(
                    np.sum(binned == j) / np.sum(binned < (nbins // 2 + 1))
                )
            for k in range(1, nbins // 2 + 1):
                participant_props.append(
                    np.sum(binned == (k + nbins // 2)) / np.sum(binned > nbins // 2)
                )
            participant_props = [p / 2 for p in participant_props]
            props.append(participant_props)

    props = np.array(props)

    # Run statistics
    expectation = np.full(nbins, 1 / nbins)
    output["pvals"] = []
    output["difference"] = []
    output["diff_perc"] = []

    for i in range(nbins):
        pval, stats = catt_bootstrap_diff(props[:, i], expectation[i], method="within", metric="linear")
        output["pvals"].append(pval)
        output["difference"].append(stats["difference"])
        output["diff_perc"].append(100 * stats["difference"] / expectation[i])

    # Compute proportions and bins
    output["proportions"] = np.mean(props, axis=0)
    output["bins"] = [(bins[i], bins[i + 1]) for i in range(len(bins) - 1)]
    output["bins_degrees"] = circ_rad2ang(output["bins"])

    # FDR correction
    output["FDR_threshold"] = fdr_correct(output["pvals"], alpha=0.05)
    if output["FDR_threshold"] is not None:
        output["significant"] = [p <= output["FDR_threshold"] for p in output["pvals"]]
    else:
        output["significant"] = [False] * nbins

    # Print results if verbose
    if verbose:
        print("====================================")
        print("Results from catt_consistency:")
        print("====================================")
        for i in range(nbins):
            bin_range = output["bins"][i]
            print(
                f"Bin {i + 1}, {bin_range[0] / np.pi:.2f}pi-{bin_range[1] / np.pi:.2f}pi: "
                f"difference = {output['diff_perc'][i]:.2f} percent, "
                f"pval = {output['pvals'][i]:.3f}, significant = {output['significant'][i]}"
            )
        print("====================================")

    return output
