import numpy as np
import warnings


# wrapTo2Pi(data): Map Angle data to [0, 2*pi)
# circ_mean(data): Calculates the mean of the circumference data
# circ_dist(a,b): calculates the difference between two circumferential data sets, and the result is (-pi,pi).
# circ_median(data): Calculates the median of the circumference data

def wrapTo2Pi(data):
    # Map data to [0, 2*pi)
    return np.mod(data, 2 * np.pi)


def circ_mean(data):
    # Average the data as points on the unit circle
    sin_sum = np.mean(np.sin(data))
    cos_sum = np.mean(np.cos(data))
    return np.arctan2(sin_sum, cos_sum)


def circ_dist(a, b):
   # Calculate the phase difference between the two sets of data and map the result to (-pi, pi)
    d = a - b
    d = (d + np.pi) % (2 * np.pi) - np.pi
    return d


def circ_median(data):
    # Try to find a point in the data where a half point falls within a certain semicircle.
    
    sorted_data = np.sort(data)
    # Points near the median may cross the 2pi boundary at both ends,
    # This approximation is acceptable if the data is large and evenly distributed
    n = len(data)
    if n % 2 == 1:
        return sorted_data[n // 2]
    else:
        # Even number of points, take the median of the circumference of the average of the two middle values
        m1 = sorted_data[n // 2 - 1]
        m2 = sorted_data[n // 2]
        # If the difference between the two is too large, consider circling
        # Simple direct averaging may not be suitable for circular data,
        return circ_mean(np.array([m1, m2]))


def catt_bootstrap_diff(group1, group2, design, *args):
    """
    A Python translation corresponding to the catt_bootstrap_diff function in MATLAB.

    Parameters:
    group1, group2: two groups of data, one-dimensional array
    design: 'within' or 'between'

    Optional parameters (passed by *args, unlike MATLAB, here is a simple judgment):
    - nloops (int): indicates the number of repeats. The default value is 10000
    - method: 'mean' or 'median', default 'mean'
    - data_type: 'circular' or 'linear', default: 'circular'
    - direction: 'twotailed','higher','lower', default 'twotailed'

    Return value:
    pval: indicates the p value
    stats: Dictionary containing test parameters
    """

    # Initialize default parameters
    stats = {}
    stats['opt'] = {
        'method': 'mean',
        'nloops': 10000,
        'data_type': 'circular',
        'direction': 'twotailed',
    }

    # Basic input check
    assert len(group1) > 2, "group1 must have at least three data points"
    assert len(group2) > 2, "group2 must have at least three data points"

    group1 = np.array(group1).flatten()
    group2 = np.array(group2).flatten()

    if design.lower() not in ['within', 'between']:
        raise ValueError("The design parameter must be 'within' or 'between '")
    if design.lower() == 'within':
        assert len(group1) == len(group2), "The two sets of data must be equal in length within the design"

    stats['opt']['design'] = design.lower()

    # Parse the optional parameter args, which is entered randomly in the MATLAB logical order:
    # May have strings ('median','linear','higher','lower','twotailed') and numeric values (number of loops)
    for val in args:
        if isinstance(val, str):
            # Check for possible string parameters
            if val.lower() == 'median':
                stats['opt']['method'] = 'median'
            elif val.lower() == 'linear':
                stats['opt']['data_type'] = 'linear'
            elif val.lower() == 'higher':
                stats['opt']['direction'] = 'higher'
            elif val.lower() == 'lower':
                stats['opt']['direction'] = 'lower'
            elif val.lower() == 'twotailed':
                stats['opt']['direction'] = 'twotailed'
            elif val.lower() not in ['circular', 'mean', 'median', 'linear', 'twotailed', 'higher', 'lower']:
                warnings.warn(f"The unknown string parameter {val} will be ignored.")
        elif isinstance(val, (int, float)):
            stats['opt']['nloops'] = int(val)
            assert stats['opt']['nloops'] >= 100, "At least 100 iterations are required"
        else:
            warnings.warn(f"An unknown parameter type {type(val)} will be ignored.")

    # For circular data, wrap the data to 2pi
    if stats['opt']['data_type'] == 'circular':
        # Check if it may be degrees instead of radians
        if np.max(np.abs(group1)) > 12 or np.max(np.abs(group2)) > 12:
            warnings.warn("The data may be in degrees rather than radians, please check the data format.")

        group1 = wrapTo2Pi(group1)
        group2 = wrapTo2Pi(group2)

    # Determine the diff function based on method and data type
    def linear_mean_diff(g1, g2):
        return np.mean(g1) - np.mean(g2)

    def linear_median_diff(g1, g2):
        return np.median(g1) - np.median(g2)

    if stats['opt']['method'] == 'mean':
        if stats['opt']['data_type'] == 'linear':
            diff_fcn = linear_mean_diff
        else:
            # circular mean
            if stats['opt']['design'] == 'within':
                # circ_dist(g1, g2)，then circ_mean
                diff_fcn = lambda g1, g2: circ_mean(circ_dist(g1, g2))
            else:
                # between: circ_dist( circ_mean(g1), circ_mean(g2) )
                diff_fcn = lambda g1, g2: circ_dist(circ_mean(g1), circ_mean(g2))
    else:  # median
        if stats['opt']['data_type'] == 'linear':
            diff_fcn = linear_median_diff
        else:
            if stats['opt']['design'] == 'within':
                diff_fcn = lambda g1, g2: circ_median(circ_dist(g1, g2))
            else:
                diff_fcn = lambda g1, g2: circ_dist(circ_median(g1), circ_median(g2))

    stats['opt']['diff_fcn'] = diff_fcn

    # Calculate the actual difference
    difference = diff_fcn(group1, group2)
    stats['difference'] = difference

    nloops = stats['opt']['nloops']
    null_diffs = np.zeros(nloops)

    # Resampling according to design type
    if stats['opt']['design'] == 'between':
        # Randomly shuffle combinations when sampling
        combined = np.concatenate([group1, group2])
        n1 = len(group1)
        n2 = len(group2)
        for i in range(nloops):
            # Randomly sample n1 from the combined as the new G1, leaving n2 as G2
            idx = np.random.choice(len(combined), n1, replace=False)
            G1 = combined[idx]
            G2 = combined[np.setdiff1d(np.arange(len(combined)), idx)]
            null_diffs[i] = diff_fcn(G1, G2)
    else:
        # within design, only the corresponding location data is exchanged
        for i in range(nloops):
            order = np.random.rand(len(group1)) < 0.5
            G1 = np.copy(group1)
            G2 = np.copy(group2)
            # Swap data for the order==True position
            G1[order], G2[order] = G2[order], G1[order]
            null_diffs[i] = diff_fcn(G1, G2)

    stats['null'] = null_diffs

    # Calculate the p-value according to direction
    direction = stats['opt']['direction']
    if direction == 'twotailed':
        pval = np.sum(np.abs(null_diffs) >= abs(difference)) / nloops
    elif direction == 'higher':
        pval = np.sum(null_diffs >= difference) / nloops
    else:  # 'lower'
        pval = np.sum(null_diffs <= difference) / nloops

    # Calculate the Z-score
    stats['Z'] = (difference - np.mean(null_diffs)) / np.std(null_diffs)

    return pval, stats
