import numpy as np
import warnings
from scipy.stats import pearsonr, spearmanr


def wrapTo2Pi(data):
    # Map data to [0, 2*pi)
    return np.mod(data, 2*np.pi)

def circ_corrcc(x, y):
    # Circumference-circumference-related example placeholder function,
    return np.corrcoef(np.sin(x), np.sin(y))[0,1]  

def circ_corrcl(circ, lin):
    # Circumferential - linear correlation example placeholder function
    return np.corrcoef(np.sin(circ), lin)[0,1]  

def catt_bootstrap_corr(DV1, type1, DV2, type2, *args):
    """
    Python version of catt_bootstrap_corr function

    Parameters:
    DV1, DV2: Data array (1D)
    type1, type2: 'circular' or 'linear'
    Optional parameters:
    nloops (int) : The default number is 10000
    'pearson'/'spearman' : Specifies linearly dependent methods (only valid for bilinear data, default is 'spearman')
    'twotailed'/'higher'/'lower' : check direction, default 'twotailed'

    Back:
    pval: indicates the p value
    stats: Dictionary containing test parameters and statistics
    """

    # Default parameter Settings
    stats = {}
    stats['opt'] = {}
    stats['opt']['nloops'] = 10000
    stats['opt']['test_type'] = 'spearman'
    stats['opt']['direction'] = 'twotailed'

    # Basic input check
    DV1 = np.array(DV1).flatten()
    DV2 = np.array(DV2).flatten()

    assert len(DV1) > 2, "DV1 requires at least 3 data points"
    assert len(DV2) > 2, "DV2 requires at least 3 data points"
    assert len(DV1) == len(DV2), "DV1 and DV2 must be the same length"
    assert type1.lower() in ['circular','linear'], "type1 should be 'circular' or 'linear'"
    assert type2.lower() in ['circular','linear'], "type2 should be 'circular' or 'linear'"

    # Parse optional parameters
    for val in args:
        if isinstance(val, str):
            if val.lower() in ['pearson','pearsons']:
                stats['opt']['test_type'] = 'pearson'
            elif val.lower() == 'higher':
                stats['opt']['direction'] = 'higher'
            elif val.lower() == 'lower':
                stats['opt']['direction'] = 'lower'
            elif val.lower() == 'twotailed':
                stats['opt']['direction'] = 'twotailed'
            elif val.lower() not in ['spearman','spearmans','pearson','pearsons','twotailed','higher','lower']:
                warnings.warn(f"The unknown string parameter {val} will be ignored.")
        elif isinstance(val, (int,float)):
            stats['opt']['nloops'] = int(val)
            assert stats['opt']['nloops'] >= 100, "At least 100 iterations are required"
        else:
            warnings.warn(f"The unknown parameter type {type(val)} will be ignored.")

    # Process the data in a circle
    if type1.lower() == 'circular':
        if np.max(np.abs(DV1)) > 10:
            w_msg = "DV1 data may be in degrees instead of radians, please check and try again"
            warnings.warn(w_msg)
            stats.setdefault('opt', {}).setdefault('warning', []).append(f"DV1: {w_msg}")
        DV1 = wrapTo2Pi(DV1)
        stats['opt']['dv1'] = 'circular'
    else:
        stats['opt']['dv1'] = 'linear'

    if type2.lower() == 'circular':
        if np.max(np.abs(DV2)) > 10:
            w_msg = "DV2 data may be in degrees instead of radians, please check and try again"
            warnings.warn(w_msg)
            stats.setdefault('opt', {}).setdefault('warning', []).append(f"DV2: {w_msg}")
        DV2 = wrapTo2Pi(DV2)
        stats['opt']['dv2'] = 'circular'
    else:
        stats['opt']['dv2'] = 'linear'

    # Determine the correlation function according to the type
    dv1_type = stats['opt']['dv1']
    dv2_type = stats['opt']['dv2']
    test_type = stats['opt']['test_type']

    if dv1_type == 'circular' and dv2_type == 'circular':
        r_fcn = circ_corrcc
    elif dv1_type == 'circular' and dv2_type == 'linear':
        r_fcn = circ_corrcl
    elif dv1_type == 'linear' and dv2_type == 'circular':
        # circ_corrcl requires the first argument to be circular data, so switch the argument order
        r_fcn = lambda x,y: circ_corrcl(y,x)
    else:
        # dv1_type='linear' & dv2_type='linear'
        # spearman or pearson correlation according to test type
        if test_type == 'spearman':
            r_fcn = lambda x,y: spearmanr(x,y)[0]
        else:
            r_fcn = lambda x,y: pearsonr(x,y)[0]

    stats['opt']['r_fcn'] = r_fcn

    # Calculate the original correlation
    rho = r_fcn(DV1, DV2)
    stats['rho'] = rho

    nloops = stats['opt']['nloops']
    null_vals = np.zeros(nloops)

    # Resampling shuffles DV2 and calculates the empty distribution
    for i in range(nloops):
        dv2_shuffled = np.random.permutation(DV2)
        null_vals[i] = r_fcn(DV1, dv2_shuffled)

    stats['null'] = null_vals

    direction = stats['opt']['direction']
    if direction == 'twotailed':
        pval = np.sum(np.abs(null_vals) >= abs(rho)) / nloops
    elif direction == 'higher':
        pval = np.sum(null_vals >= rho) / nloops
    else:  # 'lower'
        pval = np.sum(null_vals <= rho) / nloops

    return pval, stats
