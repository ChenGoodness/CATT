import numpy as np
from scipy.stats import circmean

def catt_bin_circ_data(thetas, nbins):
    """
    Bin data into specified bins.

    Parameters:
        thetas: ndarray
            An n x 1 vector containing the angular data you want to bin.
        nbins: int
            The number of equally spaced bins you want.

    Returns:
        binned_data: ndarray
            An n x 1 vector containing the bin that each value in data belongs to (from 1-nbins).
        bin_centres: ndarray
            The centres of the bins, in radians.
        LL: ndarray
            The lower limits of the bins, in radians.
        UL: ndarray
            The upper limits of the bins, in radians.
    """
    # Get equally spaced bins
    bins = np.linspace(0, 2 * np.pi, nbins + 1)

    # Get lower and upper limits of the bins
    LL = bins[:-1]  # Lower limits
    UL = bins[1:]   # Upper limits

    # Get bin centres
    bin_centres = (LL + UL) / 2

    # Wrap thetas to [0, 2pi)
    thetas = np.mod(thetas, 2 * np.pi)

    # Initialize binned output
    binned_data = np.full(thetas.shape, np.nan)

    current_bin = 1

    while current_bin < len(bins):
        # Find the thetas less than the current bin upper limit
        idx = np.where(thetas < bins[current_bin])[0]

        # Assign these to the current bin
        binned_data[idx] = current_bin

        # Remove these thetas from the search list
        thetas[idx] = np.nan

        # Update current bin
        current_bin += 1

    # Remaining values are at the boundary (2pi = 0), assign to the first bin
    idx = np.where(~np.isnan(thetas))[0]
    binned_data[idx] = 1

    return binned_data, bin_centres, LL, UL
