import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import zscore
import catt_opts


def catt_bpm2ibi(bpm):
    """
    Convert beats per minute (BPM) to inter-beat interval (IBI) in milliseconds.
    """
    return 60000 / bpm  # 1 minute = 60000 ms


def catt_IBI(catt, plot_on=False):
    """
    Calculate IBIs, screen for bad trials, and calculate the IBI of the cycle in which onset appeared.

    Parameters:
    catt : dict
        A dictionary containing:
        - catt["RR"]: List of dictionaries with "times" (list of time values in ms).
    plot_on : bool, optional
        If True, plot histogram for retained IBIs and excluded IBIs. Default is False.
    catt_opts : dict, optional
        A dictionary containing the following keys:
        - BPM_extreme_z: Maximum Z-score for valid IBIs.
        - BPM_max: Maximum allowed BPM.
        - BPM_min: Minimum allowed BPM.

    Returns:
    catt : dict
        Updated catt dictionary with the following keys:
        - catt["RR"]: Filtered list of RR intervals with valid IBIs.
        - catt["rej"]: Rejection details for excluded IBIs.
    """

    # Extract options from catt_opts
    BPM_extreme_z = catt_opts.catt_opts["BPM_extreme_z"]
    BPM_max = catt_opts.catt_opts["BPM_max"]
    BPM_min = catt_opts.catt_opts["BPM_min"]

    # =================================================
    #  Get inter-beat intervals (IBIs)
    # =================================================
    IBIs = []
    for rr in catt["RR"]:
        IBI = rr["times"][-1] - rr["times"][0]
        rr["IBI"] = IBI  # Add IBI to each RR
        IBIs.append(IBI)

    IBIs = np.array(IBIs)

    # =================================================
    #  Screen for bad IBIs
    # =================================================
    # Identify extreme IBIs based on Z-score
    extreme = np.where(np.abs(zscore(IBIs)) > BPM_extreme_z)[0]
    # Identify IBIs that are too fast or too slow
    too_fast = np.where(IBIs < catt_bpm2ibi(BPM_max))[0]
    too_slow = np.where(IBIs > catt_bpm2ibi(BPM_min))[0]

    # Combine all bad indices
    bad = np.unique(np.concatenate([extreme, too_fast, too_slow]))
    ok = np.setdiff1d(np.arange(len(IBIs)), bad)

    # Filter RR intervals and store rejection details
    catt["rej"] = {
        "removed_for_bad_IBI": bad.tolist(),
        "orig_post_manual_rejection": catt["RR"],
        "prop_IBIs_removed": len(bad) / (len(bad) + len(ok))
    }
    catt["RR"] = [catt["RR"][i] for i in ok]

    # =================================================
    #  Plot histogram of IBIs (removed & retained)
    # =================================================
    if plot_on:
        plt.figure(figsize=(12, 6))

        # Plot retained IBIs
        plt.subplot(1, 2, 1)
        plt.hist(IBIs[ok], bins=20, color=[0.3, 0.7, 0.4], edgecolor='black')
        plt.xlabel('IBI (ms)', fontsize=15)
        plt.ylabel('Count', fontsize=15)
        plt.title('IBIs (Retained)', fontsize=17)
        plt.grid(True)

        # Plot excluded IBIs
        plt.subplot(1, 2, 2)
        plt.hist(IBIs[bad], bins=20, color=[0.62, 0.6, 0.6], edgecolor='black')
        plt.xlabel('IBI (ms)', fontsize=15)
        plt.ylabel('Count', fontsize=15)
        plt.title('IBIs (Excluded)', fontsize=17)
        plt.grid(True)

        plt.tight_layout()
        plt.show()

    return catt