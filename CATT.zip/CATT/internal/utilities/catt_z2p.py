import numpy as np
from scipy.stats import norm


def catt_z2p(X):
    """
    Combine z-scores from all participants' individual tests
    using Stouffer's method to get a group-level z-score and a group-level p-value.

    Parameters:
    -----------
    X : list, dict, or ndarray
        - If X is a list of dictionaries, it is assumed to be group data, where each element contains z-score information.
        - If X is an ndarray or list of z-scores, it is processed directly.
        - If X is a single z-score, a corresponding p-value will be computed.

    Returns:
    --------
    P : float
        The p-value for the single z-score or the combined group-level p-value.
    Z : float
        The combined group-level z-score.
    """

    # Case 1: X is an ndarray or list of z-scores
    if isinstance(X, (np.ndarray, list)) and not isinstance(X, dict):
        if len(X) == 1:
            # Single z-score, convert to p-value
            Z = X[0]
        elif len(X) > 1:
            # Calculate the combined z-score using Stouffer's method
            Z = np.nansum(X) / np.sqrt(len(X))

    # Case 2: X is a list of dictionaries (group structure)
    elif isinstance(X, list) and all(isinstance(x, dict) for x in X):
        z = [x['stats']['zscore'] for x in X]
        Z = np.nansum(z) / np.sqrt(len(z))

    # Case 3: X is a dictionary (assuming group structure for participants)
    elif isinstance(X, dict):
        z = [X[key]['stats']['zscore'] for key in X]
        Z = np.nansum(z) / np.sqrt(len(z))

    else:
        raise ValueError("Unknown input type. Please check the documentation for the function.")

    # Get two-tailed p-value
    P = 2 * (1 - norm.cdf(abs(Z)))

    return P, Z
