import numpy as np

from dependencies.shuffle import shuffle


def catt_shuffle(IBIs, onsets):
    IBIs = IBIs.astype(float)  # Convert IBIs to floating point type
    # Arrange and sort
    IBIs = np.reshape(IBIs, (1, -1)).flatten()
    onsets = np.reshape(onsets, (1, -1)).flatten()

    # Sort in descending order
    IBIs = np.sort(IBIs)[::-1]
    onsets = np.sort(onsets)[::-1]

    # Prepare shuffled_IBIs
    shuffled_IBIs = np.full(onsets.shape, np.nan)

    # Pair the complicated ones first
    i = 0
    while (not np.isnan(IBIs[-1])) and (onsets[i] > IBIs[-1]) and (np.any(~np.isnan(IBIs))):
        # Find all IBIs greater than or equal to the current onset
        try:
            idx = np.where(IBIs >= onsets[i])[0]
            t = idx[np.random.randint(len(idx))]
        except:
            print('<strong>Error in catt_shuffle. Do you have some cases where onset > IBI?</strong>')
            print('<strong>Retrying excluding these trials...</strong>')
            break

        # Add it into the shuffled dataset
        shuffled_IBIs[i] = IBIs[t]

        # Remove the selected datapoint from the IBIs
        IBIs[t] = np.nan

        # Update ticker
        i += 1

    # Shuffle the remaining
    remaining_IBIs = IBIs[~np.isnan(IBIs)]
    shuffled_remaining, _, _ = shuffle(remaining_IBIs)
    shuffled_IBIs[i:] = shuffled_remaining

    return shuffled_IBIs, onsets

