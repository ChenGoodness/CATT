import numpy as np
import catt_opts

def catt_ibi2bpm(IBIs):
    """
    Convert inter-beat intervals (IBIs) in milliseconds to beats per minute (BPM).
    """
    return 60000 / np.array(IBIs)

def catt_estimate_qt(catt):
    """
    Compute QT interval estimate from ECG data.

    Parameters:
    catt : dict
        A dictionary containing participant's data, including:
        - catt["RR"]: List of dictionaries with "IBI" (inter-beat intervals in ms).
    catt_opts : dict
        A dictionary containing options for QT estimation, including:
        - "qt_method": Method for estimating QT interval.
        - "qt_default": Default QT interval (in ms).
        - "qr": Additional correction term (used for 'data' method).

    Returns:
    catt : dict
        Updated dictionary with estimated QT interval stored in catt["qt"].
    """
    # Get default QT value
    qt_method = catt_opts.catt_opts.get("qt_method", "fixed")

    if qt_method != "fixed":
        # Get BPM from IBIs
        IBIs = [rr["IBI"] for rr in catt["RR"]]
        catt["est_bpm"] = catt_ibi2bpm(IBIs)

    # Estimate QTc based on the selected method
    if qt_method == "bazett":
        catt["qt"] = catt_opts.catt_opts["qt_default"] / np.sqrt(catt["est_bpm"] / 60)
    elif qt_method == "fridericia":
        catt["qt"] = catt_opts.catt_opts["qt_default"] / np.cbrt(catt["est_bpm"] / 60)
    elif qt_method == "sagie":
        catt["qt"] = 1000 * ((catt_opts.catt_opts["qt_default"] / 1000) + 0.154 * (1 - (catt["est_bpm"] / 60)))
    elif qt_method == "fixed":
        catt["qt"] = catt_opts.catt_opts["qt_default"]
    elif qt_method == "data":
        # Compute QT interval based on RT (reaction time) and QR offset
        onsets = np.array([rr.get("onset", np.nan) for rr in catt["RR"]])
        RT = np.array([rr.get("RT", np.nan) for rr in catt["RR"]])
        valid_RT = RT[~np.isnan(onsets)]
        catt["qt"] = valid_RT + catt_opts.catt_opts["qr"]
    else:
        raise ValueError("Unknown or unsupported method in catt_opts['qt_method']. Please check your parameters.")

    return catt
