import numpy as np
import math

# Assuming catt_opts is defined globally and catt_init has been called
import catt_opts

def catt_wrap2heart(*args):
    """
    Express an onset as a function of its position in a cardiac cycle.

    Args:
        (i) catt: dict representing a catt structure.
        OR
        (ii) onsets, IBIs, qt: separate arrays of onsets, IBIs, and qt intervals.

    Returns:
        wrapped: dict with the wrapped values, including onsets expressed as radians.
    """
    # Get settings, initialise outputs
    wrapped = {}

    # if working with a catt input
    if len(args) == 1 and isinstance(args[0], dict):
        catt = args[0]

        # get the onsets, responses & qts
        onsets = []
        responses = []
        IBIs = []
        for item in catt['RR']:
            onsets.append(item['onset'])
            responses.append(item['response'])
            IBIs.append(item['IBI'])
        onsets = np.array(onsets).reshape(-1, 1)
        responses = np.array(responses).reshape(-1, 1)
        IBIs = np.array(IBIs).reshape(-1, 1)

        # onsets = np.array(catt['RR']['onset']).reshape(-1, 1)
        # responses = np.array(catt['RR']['response']).reshape(-1, 1)
        qt = np.array(catt['qt']).reshape(-1, 1)
        # IBIs = np.array(catt['RR']['IBI']).reshape(-1, 1)

        if len(qt) == 1:
            qt = qt * np.ones_like(IBIs)

    # if working with 3 separate inputs (e.g., for bootstrapping)
    elif len(args) == 3:
        onsets = np.array(args[0]).reshape(-1, 1)
        IBIs = np.array(args[1]).reshape(-1, 1)
        qt = np.array(args[2]).reshape(-1, 1)

        # if qt is same for all, replicate
        if len(qt) == 1:
            qt = qt * np.ones_like(onsets)

        onsets = np.reshape(onsets, (len(onsets), 1))
        IBIs = np.reshape(IBIs, (len(IBIs), 1))
        qt = np.reshape(qt, (len(qt), 1))

        # ensure responses are in the right format
        responses = np.full_like(IBIs, np.nan)

    # otherwise, raise an error
    else:
        raise ValueError("Inputs should be either a catt structure, or onsets, IBIs, and qts.")

    # Boot out data without an onset
    valid_idx = ~np.isnan(onsets)
    responses = responses[valid_idx]
    IBIs = IBIs[valid_idx]
    onsets = onsets[valid_idx]

    # get the IBIs for all trials where there's an onset + load into wrapped
    wrapped['onsets_msec'] = onsets
    wrapped['IBIs'] = IBIs
    wrapped['responses'] = responses
    wrapped['method'] = catt_opts.catt_opts['wrap2']

    # Prepare output
    wrapped['onsets_rad'] = np.full_like(onsets, np.nan)

    # if using the fixed method, get rt from qt and qr.
    if catt_opts.catt_opts['qr'] != 'data':
        rt = qt - catt_opts.catt_opts['qr']
    wrapped['rt'] = rt

    # Method 1: Wrap to t-wave
    if catt_opts.catt_opts['wrap2'].lower() == 'twav':
        # First, get the trials where the onset was before the t-wave.
        idx = np.where(np.diag(onsets <= wrapped['rt']))
        wrapped['onsets_rad'][idx] = ((onsets[idx].reshape(-1, 1) - wrapped['rt'][idx]) / wrapped['rt'][idx]).ravel()

        # Second, get the trials where the onset was after the t-wave.
        idx = np.where(np.diag(onsets > wrapped['rt']))
        wrapped['onsets_rad'][idx] = ((onsets[idx].reshape(-1, 1) - wrapped['rt'][idx]) / np.diag((wrapped['IBIs'][idx].reshape(-1, 1) - wrapped['rt'][idx]))).ravel()

        # Finally, convert to radians
        wrapped['onsets_rad'] = wrapped['onsets_rad'].astype(np.float64) * math.pi

    # Method 2: Wrap to r-peak
    elif catt_opts.catt_opts['wrap2'].lower() == 'rpeak':
        # Express each onset as a proportion of the IBI
        wrapped['onsets_rad'] = onsets / wrapped['IBIs']

        # Convert to radians
        wrapped['onsets_rad'] *= 2 * math.pi

    return wrapped
