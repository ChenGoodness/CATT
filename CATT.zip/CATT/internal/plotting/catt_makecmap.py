import numpy as np

def catt_makecmap(col0, col1):
    """
    Create a color map that transitions from col0 to col1.

    Parameters:
        col0: tuple or list
            RGB values of the starting color (0-1 range).
        col1: tuple or list
            RGB values of the ending color (0-1 range).

    Returns:
        cmap: ndarray
            A 256x3 array representing the color map.
    """
    r0, g0, b0 = col0
    r1, g1, b1 = col1

    cmap = np.vstack((
        np.linspace(r0, r1, 256),
        np.linspace(g0, g1, 256),
        np.linspace(b0, b1, 256)
    )).T

    return cmap
