import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import circmean, circstd

def catt_plot_circ(data, labels, participants='off', histogram='on', mean='off', quantity='probability', zero='systole'):
    """
    Circular histogram for two responses.

    Parameters:
        data: list of ndarrays
            An ngroups x 1 list containing the data (in radians) for each group.
        labels: list of str
            An ngroups x 1 list containing the names of each group for the legend.
        participants: str, optional
            'on' or 'off'. Plot individual data points. Default is 'off'.
        histogram: str, optional
            'on' or 'off'. Plot the circular histogram. Default is 'on'.
        mean: str, optional
            'on' or 'off'. Plot the mean resultant vector. Default is 'off'.
        quantity: str, optional
            'probability' or 'count'. Specify whether histograms display probability or count. Default is 'probability'.
        zero: str, optional
            'systole' or 'diastole'. Specify whether 0/2pi is systole or diastole. Default is 'systole'.

    Returns:
        None
    """
    ngroups = len(data)

    # Assert data and labels have the same number of entries
    assert len(labels) == len(data), "Error: data and labels must have the same number of entries."

    # Check for valid inputs
    assert quantity in ['probability', 'count'], "Error: quantity should be 'probability' or 'count'."
    assert zero in ['systole', 'diastole'], "Error: zero should be 'systole' or 'diastole'."

    # Create colors
    cmap = plt.cm.viridis(np.linspace(0.15, 0.85, ngroups))
    cols = [cmap[i] for i in range(ngroups)]

    # Create axis labels
    if zero == 'diastole':
        ticks = [
            'Diastole (T)', '', '',
            'T-R midpoint', '', '',
            'Systole (R)', '', '',
            'R-T midpoint', '', ''
        ]
    else:  # 'systole'
        ticks = [
            'Systole (R)', '', '',
            'R-T midpoint', '', '',
            'Diastole (T)', '', '',
            'T-R midpoint', '', ''
        ]

    fig, ax = plt.subplots(subplot_kw={'projection': 'polar'})

    # Plot histogram
    if histogram == 'on':
        for i in range(ngroups):
            h = ax.hist(
                data[i], bins=20, density=(quantity == 'probability'),
                alpha=0.6, color=cols[i], edgecolor=cols[i], label=labels[i]
            )

    # Plot mean resultant vector
    if mean == 'on':
        for i in range(ngroups):
            theta = circmean(data[i])
            r = circstd(data[i])
            ax.plot([theta, theta], [0, r], color=cols[i], linewidth=2)

    # Plot individual data points
    if participants == 'on':
        for i in range(ngroups):
            ax.scatter(
                data[i],
                np.ones(len(data[i])) * ax.get_rmax() * 0.9,
                color=cols[i], s=10, label=f"{labels[i]} points"
            )

    # Format plot
    ax.set_theta_zero_location('E')
    ax.set_theta_direction(-1)
    ax.set_xticks(np.linspace(0, 2 * np.pi, len(ticks)))
    ax.set_xticklabels(ticks)

    ax.legend(loc='upper right', bbox_to_anchor=(1.1, 1.1))
    plt.show()

# Example usage
data = [
    np.random.vonmises(mu=0, kappa=1, size=100),
    np.random.vonmises(mu=np.pi, kappa=1, size=100)
]
labels = ['Group 1', 'Group 2']
catt_plot_circ(data, labels, participants='on', mean='on', histogram='on')
