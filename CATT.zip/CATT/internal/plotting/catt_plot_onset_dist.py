import numpy as np
import matplotlib.pyplot as plt

def catt_plot_onset_dist(catt):
    """
    Plot the distribution of onset times relative to the last R-peak.

    Parameters:
        catt: dict
            A dictionary containing preprocessed data with keys 'wrapped', 'responses'.

    Returns:
        None
    """
    # Check for wrapped onsets
    if 'wrapped' not in catt or 'onsets_msec' not in catt['wrapped']:
        raise ValueError("Error: Have you called catt_wrap2heart yet? This is needed for this function.")

    onsets = catt['wrapped']['onsets_msec']
    IBIs = catt['wrapped']['IBIs']
    responses = catt['wrapped'].get('responses', np.ones(len(onsets)))

    # Sort trials by onset time
    sorted_idx = np.argsort(onsets)
    sorted_onsets = onsets[sorted_idx]
    sorted_IBIs = IBIs[sorted_idx]
    sorted_responses = responses[sorted_idx]

    # Generate colors for responses
    unique_responses = np.unique(sorted_responses[~np.isnan(sorted_responses)])
    if len(unique_responses) < 4:
        cmap = plt.cm.viridis(np.linspace(0.2, 0.8, len(unique_responses)))
        color_map = {resp: cmap[i] for i, resp in enumerate(unique_responses)}
    else:
        color_map = {resp: plt.cm.viridis(resp) for resp in unique_responses}

    # Plot each trial's onset distribution
    fig, ax = plt.subplots(figsize=(10, 6))
    for i, idx in enumerate(sorted_idx):
        ax.plot([0, sorted_IBIs[i]], [i, i], color='black', linewidth=0.5)
        ax.scatter(sorted_onsets[i], i, color=color_map.get(sorted_responses[i], 'gray'), s=20)

    # Format plot
    ax.set_xlim(-50, np.max(sorted_IBIs) + 50)
    ax.set_ylim(-5, len(onsets) + 5)
    ax.set_xlabel("Time since last R-peak (msec)")
    ax.set_ylabel("Trials")
    ax.set_title("Onset time (dots) relative to the last R-peak\nLine length = IBI")

    # Add colorbar for responses
    sm = plt.cm.ScalarMappable(cmap=plt.cm.viridis, norm=plt.Normalize(vmin=np.min(unique_responses), vmax=np.max(unique_responses)))
    sm.set_array([])
    cbar = plt.colorbar(sm, ax=ax)
    cbar.set_label("Response")

    plt.show