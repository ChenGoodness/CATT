import numpy as np


def circ_r(alpha, w=None, d=0):
    """
    Computes the mean resultant length for circular data.

    Parameters:
    alpha : array-like
        Sample of angles in radians.
    w : array-like, optional
        Number of incidences in case of binned angle data.
    d : float, optional
        Spacing of bin centers for binned data, in radians.

    Returns:
    r : float
        Mean resultant length.
    """
    if w is None:
        # If w is not provided, assume each angle has a weight of 1
        w = np.ones_like(alpha)

    # Calculate the weighted sum of the sine and cosine components
    sum_sin = np.sum(w * np.sin(alpha))
    sum_cos = np.sum(w * np.cos(alpha))
    r = np.sqrt(sum_sin ** 2 + sum_cos ** 2) / np.sum(w)

    # Apply correction for binned data, if spacing is provided
    if d > 0:
        r = r * (np.pi / 2) / np.sin(d / 2)

    return r


def circ_rtest(alpha, w=None, d=0):
    """
    Perform Rayleigh test for non-uniformity of circular data.

    Parameters:
    alpha : array-like
        Sample of angles in radians.
    w : array-like, optional
        Number of incidences in case of binned angle data.
    d : float, optional
        Spacing of bin centers for binned data, in radians.

    Returns:
    pval : float
        p-value of Rayleigh's test.
    z : float
        Value of the z-statistic.
    """
    # Ensure alpha is a column vector
    alpha = np.asarray(alpha).flatten()

    # Compute the mean resultant length
    r = circ_r(alpha, w, d)

    # Number of samples (or effective sample size for binned data)
    n = np.sum(w) if w is not None else len(alpha)

    # Compute Rayleigh's R
    R = n * r

    # Compute Rayleigh's z
    z = R ** 2 / n

    # Compute p-value using approximation in Zar
    pval = np.exp(np.sqrt(1 + 4 * n + 4 * (n ** 2 - R ** 2)) - (1 + 2 * n))

    return pval, z
