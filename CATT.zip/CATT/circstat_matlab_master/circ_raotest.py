import numpy as np


def circ_rad2ang(alpha):
    """Convert radians to degrees."""
    return np.degrees(alpha)


def circ_raotest(alpha):
    """
    Perform Rao's spacing test for circular uniformity.

    Parameters:
    alpha : array-like
        Sample of angles in radians.

    Returns:
    p : float
        Smallest p-value at which the test would be significant.
    U : float
        Computed value of the test statistic U.
    UC : float
        Critical value of the test statistic at the significance level.
    """
    # Convert radians to degrees for the test
    alpha = np.sort(circ_rad2ang(alpha))
    n = len(alpha)

    # Calculate the test statistic U
    U = 0
    lambda_val = 360 / n
    for j in range(n - 1):
        ti = alpha[j + 1] - alpha[j]
        U += abs(ti - lambda_val)

    tn = (360 - alpha[-1] + alpha[0])
    U += abs(tn - lambda_val)
    U *= 0.5

    # Get the critical value and p-value
    p, UC = getVal(n, U)
    return p, U, UC


def getVal(N, U):
    """
    Retrieve critical values and p-values from table based on sample size and U.

    Parameters:
    N : int
        Sample size.
    U : float
        Calculated U statistic from the test.

    Returns:
    p : float
        Smallest p-value for which the test would be significant.
    UC : float
        Critical U value at the significance level.
    """
    # Critical values from Russell and Levitin, 1995
    alpha = [0.001, 0.01, 0.05, 0.10]
    table = np.array([
        [4, 247.32, 221.14, 186.45, 168.02],
        [5, 245.19, 211.93, 183.44, 168.66],
        [6, 236.81, 206.79, 180.65, 166.30],
        [7, 229.46, 202.55, 177.83, 165.05],
        [8, 224.41, 198.46, 175.68, 163.56],
        [9, 219.52, 195.27, 173.68, 162.36],
        [10, 215.44, 192.37, 171.98, 161.23],
        [11, 211.87, 189.88, 170.45, 160.24],
        [12, 208.69, 187.66, 169.09, 159.33],
        [13, 205.87, 185.68, 167.87, 158.50],
        [14, 203.33, 183.90, 166.76, 157.75],
        [15, 201.04, 182.28, 165.75, 157.06],
        [16, 198.96, 180.81, 164.83, 156.43],
        [17, 197.05, 179.46, 163.98, 155.84],
        [18, 195.29, 178.22, 163.20, 155.29],
        [19, 193.67, 177.08, 162.47, 154.78],
        [20, 192.17, 176.01, 161.79, 154.31],
        [21, 190.78, 175.02, 161.16, 153.86],
        [22, 189.47, 174.10, 160.56, 153.44],
        [23, 188.25, 173.23, 160.01, 153.05],
        [24, 187.11, 172.41, 159.48, 152.68],
        [25, 186.03, 171.64, 158.99, 152.32],
        [26, 185.01, 170.92, 158.52, 151.99],
        [27, 184.05, 170.23, 158.07, 151.67],
        [28, 183.14, 169.58, 157.65, 151.37],
        [29, 182.28, 168.96, 157.25, 151.08],
        [30, 181.45, 168.38, 156.87, 150.80],
        [35, 177.88, 165.81, 155.19, 149.59],
        [40, 174.99, 163.73, 153.82, 148.60],
        [45, 172.58, 162.00, 152.68, 147.76],
        [50, 170.54, 160.53, 151.70, 147.05],
        [75, 163.60, 155.49, 148.34, 144.56],
        [100, 159.45, 152.46, 146.29, 143.03],
        [150, 154.51, 148.84, 143.83, 141.18],
        [200, 151.56, 146.67, 142.35, 140.06],
        [300, 148.06, 144.09, 140.57, 138.71],
        [400, 145.96, 142.54, 139.50, 137.89],
        [500, 144.54, 141.48, 138.77, 137.33],
        [600, 143.48, 140.70, 138.23, 136.91],
        [700, 142.66, 140.09, 137.80, 136.59],
        [800, 142.00, 139.60, 137.46, 136.33],
        [900, 141.45, 139.19, 137.18, 136.11],
        [1000, 140.99, 138.84, 136.94, 135.92]
    ])

    # Find the row corresponding to the sample size
    ridx = np.where(table[:, 0] >= N)[0][0]
    row = table[ridx, 1:]

    # Find the column where the U statistic exceeds the critical value
    cidx = np.where(row < U)[0]

    if cidx.size > 0:
        UC = row[cidx[0]]
        p = alpha[cidx[0]]
    else:
        UC = row[-2]
        p = 0.5
    return p, UC
