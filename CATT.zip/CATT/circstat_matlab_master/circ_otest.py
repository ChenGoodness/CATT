import numpy as np
from scipy.special import gammaln


def circ_ang2rad(deg):
    """Convert degrees to radians."""
    return np.radians(deg)


def circ_otest(alpha, sz=None, w=None):
    """
    Perform Omnibus (Hodges-Ajne) test for non-uniformity of circular data.

    Parameters:
    alpha : array-like
        Sample of angles in radians.
    sz : float, optional
        Step size for evaluating distribution, default is 1 degree (in radians).
    w : array-like, optional
        Number of incidences in case of binned angle data.

    Returns:
    pval : float
        p-value of the Omnibus test.
    m : int
        Minimum number of samples falling in one half of the circle.
    """
    # Ensure alpha is a column vector
    alpha = np.asarray(alpha).flatten()

    # Set default step size to 1 degree in radians if not provided
    if sz is None:
        sz = circ_ang2rad(1)

    # Set weights to ones if not provided
    if w is None:
        w = np.ones_like(alpha)
    else:
        w = np.asarray(w)
        if len(alpha) != len(w):
            raise ValueError("Input length does not match.")

    # Modulo operation to ensure angles are within [0, 2*pi]
    alpha = np.mod(alpha, 2 * np.pi)
    n = np.sum(w)  # Total weight or sample size
    dg = np.arange(0, np.pi + sz, sz)

    # Calculate minimum number of samples in one half of the circle
    # m1 = np.array([np.sum((alpha > d) & (alpha < np.pi + d) * w) for d in dg])
    m1 = np.zeros_like(dg)
    m2 = np.zeros_like(dg)
    for i in range(len(dg)):
        condition = (alpha > dg[i]) & (alpha < np.pi + dg[i])  
        m1[i] = np.sum(condition * w)
        m2[i] = n - m1[i]

    m = np.min(np.minimum(m1, m2))

    # Calculate p-value
    if n > 50:
        # Approximation by Ajne (1968)
        A = (np.pi * np.sqrt(n)) / (2 * (n - 2 * m))
        pval = (np.sqrt(2 * np.pi) / A) * np.exp(-np.pi ** 2 / (8 * A ** 2))
    else:
        # Exact formula by Hodges (1955) with improved numerical stability
        pval = np.exp((1 - n) * np.log(2) + np.log(n - 2 * m) +
                      gammaln(n + 1) - gammaln(m + 1) - gammaln(n - m + 1))

    return pval, m
