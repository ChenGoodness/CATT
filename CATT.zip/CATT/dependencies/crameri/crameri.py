import numpy as np
import matplotlib.pyplot as plt
import scipy
from scipy.interpolate import interp1d

def crameri(colormap_name=None, n_levels=256, pivot=None):
    """
    Returns perceptually-uniform scientific colormaps created by Fabio Crameri.

    Parameters:
    -----------
    colormap_name : str, optional
        Name of the colormap to load. Prefix with '-' to invert the colormap.
    n_levels : int, optional
        Number of levels in the colormap. Default is 256.
    pivot : float, optional
        Center a diverging colormap such that white corresponds to a given value.

    Returns:
    --------
    cmap : np.ndarray
        The colormap array (n_levels x 3).
    """
    if colormap_name is None:
        # Display available colormaps
        try:
            img = plt.imread('crameri6.0.png')
            plt.figure(figsize=(10, 6))
            plt.imshow(img)
            plt.axis('off')
            plt.title('Available Colormap Options')
            plt.show()
        except FileNotFoundError:
            print("Colormap options image ('crameri6.0.png') not found.")
        return

    # Check if the colormap should be inverted
    inverted = False
    if colormap_name.startswith('-'):
        inverted = True
        colormap_name = colormap_name[1:]

    # Standardize colormap name to lowercase
    colormap_name = colormap_name.lower()

    # Alias for 'oleron' colormap
    if colormap_name in ['dem', 'topo']:
        colormap_name = 'oleron'

    # Load the colormap data from a .mat file
    try:
        mat_data = scipy.io.loadmat(r'E:\PythonProjects\CATT\dependencies\crameri\CrameriColourMaps.mat')
        if colormap_name in mat_data:
            cmap = mat_data[colormap_name]
        else:
            raise ValueError
    except (FileNotFoundError, ValueError):
        print(f"Unknown colormap name '{colormap_name}'. Try running with no inputs to check options.")
        return

    # Interpolate colormap to specified number of levels
    if n_levels != cmap.shape[0]:
        x = np.linspace(0, 1, cmap.shape[0])
        interp = interp1d(x, cmap, axis=0, kind='linear')
        cmap = interp(np.linspace(0, 1, n_levels))

    # Invert colormap if requested
    if inverted:
        cmap = np.flipud(cmap)

    # Adjust colormap for pivot if specified
    if pivot is not None:
        clim = plt.gca().get_clim()
        maxval = max(abs(clim[0] - pivot), abs(clim[1] - pivot))
        x = np.linspace(-maxval, maxval, cmap.shape[0]) + pivot
        interp = interp1d(x, cmap, axis=0, bounds_error=False, fill_value='extrapolate')
        cmap = interp(np.linspace(clim[0], clim[1], cmap.shape[0]))

    return cmap

# Example usage:
if __name__ == "__main__":
    # Show colormap options if no colormap name is given
    crameri()

    # Load and apply a colormap
    cmap = crameri('batlow', n_levels=128)
    if cmap is not None:
        plt.imshow(np.linspace(0, 1, 100).reshape(10, 10), cmap=plt.cm.colors.ListedColormap(cmap))
        plt.colorbar()
        plt.title("Crameri 'batlow' colormap")
        plt.show()
