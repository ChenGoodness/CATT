import numpy as np

def fdr_correct(p, q):
    """
    Perform FDR correction for multiple comparisons.

    Parameters:
        p: ndarray
            Vector of p-values.
        q: float
            False Discovery Rate level.

    Returns:
        pID: float
            p-value threshold based on independence or positive dependence.
        pN: float
            Nonparametric p-value threshold.
    """
    # Reshape p-values to a 1D array
    p = np.array(p).flatten()

    # Remove NaN values
    p = p[np.isfinite(p)]

    # Sort p-values
    p = np.sort(p)

    # Number of p-values
    V = len(p)

    # Create index array
    I = np.arange(1, V + 1)

    # Constants for FDR correction
    cVID = 1
    cVN = np.sum(1.0 / np.arange(1, V + 1))

    # Compute pID and pN
    pID = p[np.where(p <= I / V * q / cVID)[0][-1]] if np.any(p <= I / V * q / cVID) else None
    pN = p[np.where(p <= I / V * q / cVN)[0][-1]] if np.any(p <= I / V * q / cVN) else None

    return pID, pN