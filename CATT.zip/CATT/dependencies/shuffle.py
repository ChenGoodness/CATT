import numpy as np

def shuffle(y, dim=None):
    if y is None:
        raise ValueError("No input array 'y' provided.")

    if dim is None:
        if y.shape[0] != 1:
            dim = 1
        else:
            if y.ndim > 1 and y.shape[1] != 1:
                dim = 2
            else:
                dim = 3

    python_axis = dim - 1
    r = y.shape[python_axis]

    a = np.random.rand(r)
    i = np.argsort(a)

    if dim == 1:
        x = y[i, ...]
    elif dim == 2:
        x = y[:, i, ...]
    elif dim == 3:
        x = y[:, :, i, ...]
    elif dim == 4:
        x = y[:, :, :, i, ...]
    elif dim == 5:
        x = y[:, :, :, :, i]
    else:
        raise ValueError(f"dim={dim} not handled in this example.")

    j = np.argsort(i)

    return x, i, j