from scipy.signal import cheby1, sosfilt, sosfreqz
import numpy as np
import matplotlib.pyplot as plt

def chebyshevI_bandpass(fs, order=4, low=6, high=18, ripple=1):
    """
    Designs a Chebyshev Type I Bandpass Filter.

    Parameters:
    -----------
    fs : float
        Sampling frequency in Hz.
    order : int, optional
        Filter order. Default is 4.
    low : float, optional
        Lower cutoff frequency in Hz. Default is 6 Hz.
    high : float, optional
        Upper cutoff frequency in Hz. Default is 18 Hz.
    ripple : float, optional
        Passband ripple in dB. Default is 1 dB.

    Returns:
    --------
    sos : ndarray
        Second-order sections representation of the filter.
    """
    nyquist = fs / 2  # Nyquist frequency
    low_cutoff = low / nyquist
    high_cutoff = high / nyquist

    # Design the Chebyshev Type I filter
    sos = cheby1(order, ripple, [low_cutoff, high_cutoff], btype='band', output='sos')
    return sos
