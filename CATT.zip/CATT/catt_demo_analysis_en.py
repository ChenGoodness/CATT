import os
import numpy as np
import scipy.io as sio
import matplotlib.pyplot as plt
from scipy.stats import circmean, circstd
from statsmodels.stats.weightstats import ztest
import catt_opts
from catt_init import catt_init

from internal.stats.catt_bootstrap_clust import catt_bootstrap_clust
from internal.stats.catt_bootstrap_corr import catt_bootstrap_corr
from internal.stats.catt_bootstrap_diff import catt_bootstrap_diff
from internal.utilities.catt_IBI import catt_IBI
from internal.utilities.catt_estimate_qt import catt_estimate_qt
from internal.utilities.catt_wrap2heart import catt_wrap2heart
from internal.utilities.catt_z2p import catt_z2p




def catt_demo_analysis_en():
    catt_init()
    np.random.seed(1)
    print(f"{'#' * 50}")
    print(f"#                   CaTT Demo                  #")
    print(f"#                Analysing data               #")
    print(f"{'#' * 50}")

    print("Welcome to the CaTT demo for preprocessing data.")
    print("First, we need to set the options.")

    # Set options
    catt_opts.catt_opts["qt_method"] = "fixed"
    catt_opts.catt_opts["qt_default"] = 400
    catt_opts.catt_opts["fs"] = 1000


    print("For this dataset, we are going to assume that the q-t interval is fixed at 400ms.")
    print("We are making this assumption because the data we are using does not have continuous ECG.")
    print("We therefore cannot extract qt intervals from the data.")

    input("Press any key to continue\n")

    # Download the data
    if not os.path.exists("demo data/Blinks") or not os.path.exists("demo data/Saccades and Fixations"):
        print("We need to get the data. The data can be found here: https://osf.io/ye3rg/")
        print("The code will download the data for you.")
        input("Press any key to continue\n")

        if not os.path.exists("demo data"):
            os.makedirs("demo data")

        # Download and unzip blinks data
        print("Downloading & unzipping blinks data...")
        sio.wavfile.write("demo data/Blinks.zip", "https://osf.io/h5x84/download")
        os.system("unzip demo data/Blinks.zip -d demo data/blinks")
        print("Done.")

        # Download and unzip saccades and fixations data
        print("Downloading & unzipping saccades and fixations data...")
        sio.wavfile.write("demo data/Saccades and Fixations.zip", "https://osf.io/rbt7w/download")
        os.system("unzip demo data/Saccades and Fixations.zip -d demo data/Saccades and Fixations")
        print("Done.")

    print("\nLoading data...")

    # Load saccades and fixations data
    datafiles_saccades = [f"demo data/Saccades and Fixations/{f}" for f in os.listdir("demo data/Saccades and Fixations")]
    datafiles_blinks = [f"demo data/blinks/{f}" for f in os.listdir("demo data/blinks")]

    catt_saccades, catt_fixations, catt_blinks = [], [], []

    for subj, datafile in enumerate(datafiles_saccades):
        # Load data
        data = sio.loadmat(datafile)
        Saccades_Mx3 = data["Saccades_Mx3"]

        # Extract relevant information
        onsets_ms_saccade = Saccades_Mx3[:, 1]
        onsets_ms_fixation = Saccades_Mx3[:, 8]
        IBI_saccade = Saccades_Mx3[:, 3].copy()
        IBI_fixation = Saccades_Mx3[:, 3].copy()

        # Find the fixations index that you want to adjust
        idx = np.where(onsets_ms_fixation > IBI_fixation)[0]

        # If the idx array is not empty and the last element causes an out-of-bounds, remove it
        if idx.size > 0 and idx[-1] == len(onsets_ms_fixation) - 1:
            onsets_ms_fixation = onsets_ms_fixation[:-1]
            IBI_fixation = IBI_fixation[:-1]
            idx = idx[:-1]

        # Iterate through idx, adjusting the fixations data
        for i in idx:
            onsets_ms_fixation[i] -= IBI_fixation[i]
            IBI_fixation[i] = IBI_fixation[i + 1]

        # Create the catt_saccades and catt_fixations structures
        catt_saccades.append({
            "RR": [{
                "idx_RR": np.arange(1, IBI_saccade[i] + 1),
                "times": np.arange(1, IBI_saccade[i] + 1),
                "onset": onsets_ms_saccade[i],
                "response": np.nan
            } for i in range(len(IBI_saccade))]
        })

        catt_fixations.append({
            "RR": [{
                "idx_RR": np.arange(1, IBI_fixation[i] + 1),
                "times": np.arange(1, IBI_fixation[i] + 1),
                "onset": onsets_ms_fixation[i],
                "response": np.nan
            } for i in range(len(IBI_fixation))]
        })

        # Call the catt_IBI function to exclude extreme IBI values
        catt_saccades[subj] = catt_IBI(catt_saccades[subj])
        catt_fixations[subj] = catt_IBI(catt_fixations[subj])

        # Estimate qt (call catt_estimate_qt function)
        catt_saccades[subj] = catt_estimate_qt(catt_saccades[subj])
        catt_fixations[subj] = catt_estimate_qt(catt_fixations[subj])

    input("Press any key to continue\n")

    catt_blinks = []
    catt_opts.catt_opts["fs"] = 1000  # The sample rate is set to 1000 Hz

    for subj, datafile in enumerate(datafiles_blinks):
        # Load data
        data = sio.loadmat(datafile)
        Saccades_Mx2 = data["Saccades_Mx2"]

        # Extract relevant information
        onsets_ms_blink = Saccades_Mx2[:, 1].copy()
        IBI = Saccades_Mx2[:, 2].copy()

        # If any onsets > IBIs exist, remove them
        idx = np.where(onsets_ms_blink <= IBI)[0]
        onsets_ms_blink = onsets_ms_blink[idx]
        IBI = IBI[idx]

        # Create a structure similar to catt_epoch
        RR_list = []
        for i in range(len(IBI)):
            RR = {
                "idx_RR": np.arange(1, IBI[i] + 1),
                "times": np.arange(1, IBI[i] + 1),
                "onset": onsets_ms_blink[i],
                "response": np.nan
            }
            RR_list.append(RR)

        # Add to the catt_blinks list
        catt_blinks.append({"RR": RR_list})

        # Exclude extreme IBI values and call the catt_IBI function
        catt_blinks[subj] = catt_IBI(catt_blinks[subj])

        # Estimate qt (call catt_estimate_qt function)
        catt_blinks[subj] = catt_estimate_qt(catt_blinks[subj])
        if(subj ==0):
            break

    input("Press any key to continue\n")

    print("Running analyses...")

    for i_wrap in range(2):
        catt_opts.catt_opts["wrap2"] = "rpeak" if i_wrap == 0 else "twav"

        # for i_analysis in range(3):  # 0: fixations, 1: saccades, 2: blinks
        i_analysis = 0
        if i_analysis == 0:
            group = catt_fixations
            analysis_name = "fixations"
        elif i_analysis == 1:
            group = catt_saccades
            analysis_name = "saccades"
        else:
            group = catt_blinks
            analysis_name = "blinks"

        Z_subjs = []

        # for subj in range(len(group)):
        for subj in range(32):
            print(f"Running {analysis_name} wrapped to {catt_opts.catt_opts['wrap2']}: {subj + 1}/{len(group)}")
            # Run permutation testing
            _, stats, group[subj] = catt_bootstrap_clust(group[subj], "otest", 500)
            Z_subjs.append(stats["zscore"])

        # Combine z-scores using Stouffer's method
        P_group, Z_group = catt_z2p(Z_subjs)
        print(f"Group zval = {Z_group:.3f}, group pval = {P_group:.3f}")

        # Plot results
        fig, ax = plt.subplots()
        ax.hist(Z_subjs, 20, edgecolor="k", facecolor=[0.8, 0.6, 0.7])
        ax.axvline(x=1.96, color="k", linestyle="--", linewidth=3)
        ax.axvline(x=-1.96, color="k", linestyle="--", linewidth=3)
        ax.plot(Z_group, 5, "kp", markersize=20, markerfacecolor=[0.8, 0.3, 0.4])
        ax.set_xlabel("Z score")
        ax.set_ylabel("# Participants")
        ax.set_title(f"{analysis_name} wrapped to {catt_opts.catt_opts['wrap2']}")
        plt.savefig(f"figures/{analysis_name}/{catt_opts.catt_opts['wrap2']}.png")
        plt.savefig(f"figures/{analysis_name}/{catt_opts.catt_opts['wrap2']}.eps")
        plt.close()

        input("Press any key to continue\n")

    # Compare within-subject 'preferred phases'
    for i_wrap in range(2):
        catt_opts.catt_opts["wrap2"] = "rpeak" if i_wrap == 0 else "twav"

        phase_differences = {
            "sacc_fix": [],
            "sacc_blink": [],
            "fix_blink": []
        }

        for i in range(32):
            print(f"Running participant {i + 1}/32 wrapped to {catt_opts.catt_opts['wrap2']}")

            saccades = catt_wrap2heart(catt_saccades[i])
            fixations = catt_wrap2heart(catt_fixations[i])
            blinks = catt_wrap2heart(catt_blinks[i])

            # Compare phases
            _, stats = catt_bootstrap_diff(saccades['onsets_rad'], fixations['onsets_rad'], "between", 1000)
            phase_differences["sacc_fix"].append([stats['difference'], stats['Z']])

            _, stats = catt_bootstrap_diff(saccades['onsets_rad'], blinks['onsets_rad'], "between", 1000)
            phase_differences["sacc_blink"].append([stats['difference'], stats['Z']])

            _, stats = catt_bootstrap_diff(fixations['onsets_rad'], blinks['onsets_rad'], "between", 1000)
            phase_differences["fix_blink"].append([stats['difference'], stats['Z']])

        # Get group-level z-scores and p-values
        print(f"Wrapped to {catt_opts.catt_opts['wrap2']}:")

        P_group, Z_group = catt_z2p(np.array(phase_differences["sacc_fix"])[:, 1])
        print(f"Saccades vs fixations: zval = {Z_group:.3f}, group pval = {P_group:.3f}")

        P_group, Z_group = catt_z2p(np.array(phase_differences["sacc_blink"])[:, 1])
        print(f"Saccades vs blinks: zval = {Z_group:.3f}, group pval = {P_group:.3f}")

        P_group, Z_group = catt_z2p(np.array(phase_differences["fix_blink"])[:, 1])
        print(f"Fixations vs blinks: zval = {Z_group:.3f}, group pval = {P_group:.3f}")

        input("Press any key to continue\n")

    # Correlate preferred phases
    pref = {
        "saccades": [],
        "fixations": [],
        "blinks": []
    }

    for i in range(32):
        saccades = catt_wrap2heart(catt_saccades[i])
        fixations = catt_wrap2heart(catt_fixations[i])
        blinks = catt_wrap2heart(catt_blinks[i])

        pref["saccades"].append(circmean(saccades['onsets_rad']))
        pref["fixations"].append(circmean(fixations['onsets_rad']))
        pref["blinks"].append(circmean(blinks['onsets_rad']))

    # Run correlations
    pval, stats = catt_bootstrap_corr(pref["saccades"], "circular", pref["fixations"], "circular", 1000)
    print(f"Saccades ~ fixations: rho(30) = {stats.rho:.2f}, p = {pval:.3f}")

    pval, stats = catt_bootstrap_corr(pref["saccades"], "circular", pref["blinks"], "circular", 1000)
    print(f"Saccades ~ blinks: rho(30) = {stats.rho:.2f}, p = {pval:.3f}")

    pval, stats = catt_bootstrap_corr(pref["blinks"], "circular", pref["fixations"], "circular", 1000)
    print(f"Blinks ~ fixations: rho(30) = {stats.rho:.2f}, p = {pval:.3f}")

    print("\nDemo completed.")

if __name__ == "__main__":
    catt_demo_analysis_en()
