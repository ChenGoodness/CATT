import os
import urllib.request
import zipfile
import numpy as np
from scipy.signal import cheby2
import scipy
import catt_opts
from dependencies.crameri.crameri import crameri
from dependencies.detecting_R_peaks.chebyshevI_bandpass import chebyshevI_bandpass


def catt_init():
    """Initialize parameters for CaTT toolbox"""

    # Check dependencies
    check_dependencies()

    # Initialize parameters
    catt_opts.catt_opts = {
        'fs': 512,
        'BP_filter': chebyshevI_bandpass(512),
        'HRV_method': 'RMSSD',
        'rdetection_thresh': 100,
        'RT_min': 200,
        'RT_max': 500,
        'qt_method': 'data',
        'qt_default': 400,
        'qr': 50,
        'wrap2': 'twav',
        'BPM_max': 160,
        'BPM_min': 40,
        'BPM_extreme_z': 3,
        'plot': {
            'lw': 2,
            'axfs': 14,
            'lfs': 16,
            'ms': 50,
            'grey': [0.7, 0.7, 0.7],
            'alpha': 0.5,
            'legOri': 'Horizontal',
            'legLoc': 'SouthOutside',
            'grid': 'on',
            'circ_nbins': 15
        },
    }
    catt_opts.catt_opts['cols'] = {}
    try:
        # Attempt to load the 'romaO' colormap using the crameri function
        catt_opts.catt_opts['cols']['cmap'] = crameri('romaO')
    except Exception:
        # If an error occurs, load the colormap from the .mat file
        mat_data = scipy.io.loadmat('dependencies/romaO_color_map.mat')  # Load the .mat file
        romaO_color_map = mat_data['romaO_color_map']  # Extract the colormap (256x3 tensor)
        catt_opts.catt_opts['cols']['cmap'] = romaO_color_map

    print('The Cardiac Timing Toolbox (CaTT) v2.0')
    print('Example scripts can be found in the demos folder.')
    print('Toolbox parameters can be found in the catt_opts dictionary.')

    return catt_opts.catt_opts


def check_dependencies():
    """Check that CaTT and CircStat toolbox are added to the path"""

    if not os.path.exists('dependencies/detecting_R_peaks/chebyshevI_bandpass.py'):
        print('CaTT not fully added to path. Please add the CaTT folder and its subfolders to your Python path.')
        raise ImportError('CaTT not found')

    if not os.path.exists('dependencies/CircStat'):
        print('Downloading and unzipping CircStat toolbox...')
        urllib.request.urlretrieve('https://github.com/circstat/circstat-matlab/archive/refs/heads/master.zip',
                                   'dependencies/CircStat.zip')
        with zipfile.ZipFile('dependencies/CircStat.zip', 'r') as zip_ref:
            zip_ref.extractall('dependencies/CircStat')
        print('Done.')