import os
import numpy as np
import scipy.io as sio
import matplotlib
matplotlib.use('TkAgg')  # Display graphics in Tkinter
import matplotlib.pyplot as plt
from scipy.stats import circmean, circstd
from statsmodels.stats.weightstats import ztest
import catt_opts
from catt_init import catt_init

from internal.stats.catt_bootstrap_clust import catt_bootstrap_clust
from internal.stats.catt_bootstrap_corr import catt_bootstrap_corr
from internal.stats.catt_bootstrap_diff import catt_bootstrap_diff
from internal.utilities.catt_IBI import catt_IBI
from internal.utilities.catt_estimate_qt import catt_estimate_qt
from internal.utilities.catt_wrap2heart import catt_wrap2heart
from internal.utilities.catt_z2p import catt_z2p

import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

def catt_demo_analysis_en():
    catt_init()

    # Create GUI
    root = tk.Tk()
    root.title("CaTT Demo Analysis")

    # Create a text box to display log information
    log_text = tk.Text(root, width=80, height=20)
    log_text.pack(pady=5)

    def log_message(msg):
        """A function that prints to both the console and the GUI text box"""
        print(msg)
        log_text.insert(tk.END, msg + "\n")
        log_text.see(tk.END)
        root.update_idletasks()

    # Display welcome message
    log_message("#" * 50)
    log_message("#                   CaTT Demo                  #")
    log_message("#                Analysing data               #")
    log_message("#" * 50)

    log_message("Welcome to the CaTT demo for preprocessing data.")
    log_message("First, we need to set the options.")

    # Set options
    catt_opts.catt_opts["qt_method"] = "fixed"
    catt_opts.catt_opts["qt_default"] = 400
    catt_opts.catt_opts["fs"] = 1000

    log_message("For this dataset, we are going to assume that the q-t interval is fixed at 400ms.")
    log_message("We are making this assumption because the data we are using does not have continuous ECG.")
    log_message("We therefore cannot extract qt intervals from the data.")

    # input pause is no longer required

    # Add a drop-down menu to select analysis type
    frame_analysis = tk.Frame(root)
    frame_analysis.pack(pady=10)

    tk.Label(frame_analysis, text="Select analysis type:").pack(side=tk.LEFT, padx=5)
    analysis_options = ["fixations", "saccades", "blinks"]
    analysis_var = tk.StringVar(value=analysis_options[0])
    combo_analysis = ttk.Combobox(frame_analysis, textvariable=analysis_var, values=analysis_options, state="readonly")
    combo_analysis.pack(side=tk.LEFT, padx=5)

    # Add a drop-down menu for selecting data type folders
    frame_data_type = tk.Frame(root)
    frame_data_type.pack(pady=10)

    tk.Label(frame_data_type, text="Select data type folder:").pack(side=tk.LEFT, padx=5)
    data_type_options = ["Blinks", "Saccades and Fixations"]
    data_type_var = tk.StringVar(value=data_type_options[0])
    combo_data_type = ttk.Combobox(frame_data_type, textvariable=data_type_var, values=data_type_options, state="readonly")
    combo_data_type.pack(side=tk.LEFT, padx=5)

    folder_frame = tk.Frame(root)
    folder_frame.pack(pady=10)
    tk.Label(folder_frame, text="Select data folder:").pack(side=tk.LEFT, padx=5)
    folder_path_var = tk.StringVar()

    def select_folder():
        selected_folder = filedialog.askdirectory(title="Select data folder")
        if selected_folder:
            folder_path_var.set(selected_folder)
            log_message(f"Selected folder: {selected_folder}")

    btn_select_folder = tk.Button(folder_frame, text="Browse", command=select_folder)
    btn_select_folder.pack(side=tk.LEFT, padx=5)
    tk.Label(folder_frame, textvariable=folder_path_var).pack(side=tk.LEFT, padx=5)

    def run_analysis():
        analysis_name = analysis_var.get()
        data_type_folder = data_type_var.get()
        selected_folder = folder_path_var.get()

        if not selected_folder:
            messagebox.showerror("Error", "Please select a data folder first.")
            return

        log_message(f"Running analysis for {analysis_name} with data from folder: {selected_folder}")

        if analysis_name == "fixations":
            # Assume the data is in the Saccades and Fixations folder
            datafiles_saccades = [os.path.join(selected_folder, f) for f in os.listdir(selected_folder) if f.endswith('.mat')]
            catt_saccades, catt_fixations = [], []

            for subj, datafile in enumerate(datafiles_saccades):
                data = sio.loadmat(datafile)
                Saccades_Mx3 = data["Saccades_Mx3"]

                onsets_ms_saccade = Saccades_Mx3[:, 1]
                onsets_ms_fixation = Saccades_Mx3[:, 8]
                IBI_saccade = Saccades_Mx3[:, 3]
                IBI_fixation = Saccades_Mx3[:, 3]

                idx = np.where(onsets_ms_fixation > IBI_fixation)[0]

                if idx.size > 0 and idx[-1] == len(onsets_ms_fixation) - 1:
                    onsets_ms_fixation = onsets_ms_fixation[:-1]
                    IBI_fixation = IBI_fixation[:-1]
                    idx = idx[:-1]

                for i in idx:
                    onsets_ms_fixation[i] -= IBI_fixation[i]
                    IBI_fixation[i] = IBI_fixation[i + 1]

                catt_saccades.append({
                    "RR": [{
                        "idx_RR": np.arange(1, IBI_saccade[i] + 1),
                        "times": np.arange(1, IBI_saccade[i] + 1),
                        "onset": onsets_ms_saccade[i],
                        "response": np.nan
                    } for i in range(len(IBI_saccade))]
                })

                catt_fixations.append({
                    "RR": [{
                        "idx_RR": np.arange(1, IBI_fixation[i] + 1),
                        "times": np.arange(1, IBI_fixation[i] + 1),
                        "onset": onsets_ms_fixation[i],
                        "response": np.nan
                    } for i in range(len(IBI_fixation))]
                })

                catt_saccades[subj] = catt_IBI(catt_saccades[subj])
                catt_fixations[subj] = catt_IBI(catt_fixations[subj])

                catt_saccades[subj] = catt_estimate_qt(catt_saccades[subj])
                catt_fixations[subj] = catt_estimate_qt(catt_fixations[subj])

            group = catt_fixations

        elif analysis_name == "saccades":
            datafiles_saccades = [os.path.join(selected_folder, f) for f in os.listdir(selected_folder) if f.endswith('.mat')]
            catt_saccades = []
            for subj, datafile in enumerate(datafiles_saccades):
                data = sio.loadmat(datafile)
                Saccades_Mx3 = data["Saccades_Mx3"]
                onsets_ms_saccade = Saccades_Mx3[:, 1]
                IBI_saccade = Saccades_Mx3[:, 3]

                catt_saccades.append({
                    "RR": [{
                        "idx_RR": np.arange(1, IBI_saccade[i] + 1),
                        "times": np.arange(1, IBI_saccade[i] + 1),
                        "onset": onsets_ms_saccade[i],
                        "response": np.nan
                    } for i in range(len(IBI_saccade))]
                })

                catt_saccades[subj] = catt_IBI(catt_saccades[subj])
                catt_saccades[subj] = catt_estimate_qt(catt_saccades[subj])

            group = catt_saccades

        else:  # "blinks"
            datafiles_blinks = [os.path.join(selected_folder, f) for f in os.listdir(selected_folder) if f.endswith('.mat')]
            catt_blinks = []
            catt_opts.catt_opts["fs"] = 1000
            for subj, datafile in enumerate(datafiles_blinks):
                data = sio.loadmat(datafile)
                Saccades_Mx2 = data["Saccades_Mx2"]

                onsets_ms_blink = Saccades_Mx2[:, 1]
                IBI = Saccades_Mx2[:, 2]

                idx = np.where(onsets_ms_blink <= IBI)[0]
                onsets_ms_blink = onsets_ms_blink[idx]
                IBI = IBI[idx]

                RR_list = []
                for i in range(len(IBI)):
                    RR = {
                        "idx_RR": np.arange(1, IBI[i] + 1),
                        "times": np.arange(1, IBI[i] + 1),
                        "onset": onsets_ms_blink[i],
                        "response": np.nan
                    }
                    RR_list.append(RR)

                catt_blinks.append({"RR": RR_list})
                catt_blinks[subj] = catt_IBI(catt_blinks[subj])
                catt_blinks[subj] = catt_estimate_qt(catt_blinks[subj])

            group = catt_blinks

        catt_opts.catt_opts["wrap2"] = "rpeak"
        Z_subjs = []
        for subj in range(len(group)):
            log_message(f"Running {analysis_name} wrapped to {catt_opts.catt_opts['wrap2']}: {subj + 1}/{len(group)}")
            _, stats, _ = catt_bootstrap_clust(group[subj], "otest", 500)
            Z_subjs.append(stats["zscore"])
        P_group, Z_group = catt_z2p(Z_subjs)
        log_message(f"Group zval = {Z_group:.3f}, group pval = {P_group:.3f}")

        fig, ax = plt.subplots()
        ax.hist(Z_subjs, 20, edgecolor="k", facecolor=[0.8, 0.6, 0.7])
        ax.axvline(x=1.96, color="k", linestyle="--", linewidth=3)
        ax.axvline(x=-1.96, color="k", linestyle="--", linewidth=3)
        ax.plot(Z_group, 5, "kp", markersize=20, markerfacecolor=[0.8, 0.3, 0.4])
        ax.set_xlabel("Z score")
        ax.set_ylabel("# Participants")
        ax.set_title(f"{analysis_name} wrapped to {catt_opts.catt_opts['wrap2']}") 

        out_dir = os.path.join("figures", analysis_name)
        os.makedirs(out_dir, exist_ok=True)
        plt.savefig(os.path.join(out_dir, f"{catt_opts.catt_opts['wrap2']}.png"))
        plt.savefig(os.path.join(out_dir, f"{catt_opts.catt_opts['wrap2']}.eps"), format='eps')

        # Display images in GUI
        canvas_frame = tk.Frame(root)
        canvas_frame.pack()
        canvas = FigureCanvasTkAgg(fig, master=canvas_frame)
        canvas.draw()
        canvas.get_tk_widget().pack()
        plt.close(fig)

        messagebox.showinfo("Analysis Done", f"Analysis '{analysis_name}' done. Check the log above for details.")

    # Run analysis button
    btn_run = tk.Button(root, text="Run Analysis", command=run_analysis)
    btn_run.pack(pady=20)

    root.mainloop()

if __name__ == "__main__":
    catt_demo_analysis_en()
